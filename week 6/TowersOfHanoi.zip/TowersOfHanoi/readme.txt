Towers Of Hanoi

The program uses Javascript NOT Java and is provided here solely to demostrate the principle of recursion. Do not try to translate any code into your own Java version as it will not work! However a search on the web would probably provide Java source code examples if needed.

Double click on the file 'ahanoi.htm' to execute from within a browser. The other files are gif pictures for the graphics.

NB Execution may be depenedent on browser version, settings or plug-ins.